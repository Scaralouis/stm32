
#include "stm32f10x.h"
#include "IMU.h"
#include "Tasks.h"
#include "Maths.h"
#include "Filter.h"
#include "Control.h"
#include "struct_all.h"
#include "Led.h"
#include "Led.c"
static void delay(uint16_t n )
{
	uint16_t i,j;
	for(i=0;i<n;i++)
		for(j=0;j<8500;j++);
}

void BSP_Init(void)
{
	Uart1_Init(115200);			//??????
	ADC1_Init();				//ADC????
	SPI1_Init();				//SPI???? ??NRF24L01??
	NRF24L01_Init(22,TX);	     // NRF24L01???? ??40??
 	NRF24L01_Check(); 		     //??NRF24L01????
}


static uint8_t data[32]; //?????????
float BAT_Val,BAT_Val1;             //???????
void Bat_Vol_NRF_Tx(void) 
{
   BAT_Val = (ADC_Value[0] * 3.3) / 4096;
	  sprintf(data,"Val:%0.2f V",BAT_Val);
	  NRF_Send_TX(data,32); 	//data :????? 32:??????
}
/*void Bat_Vol_NRF_Tx(void) 
{
   BAT_Val = (ADC_Value[0] * 3.3) / 2048;
	 sprintf(data,"Val:%0.2f V",BAT_Val);
		NRF_Send_TX(data,32);
	if(  BAT_Val<3.91){
		//sprintf(data,"1111Val:%0.2f V",BAT_Val);
		//NRF_Send_TX(data,32);
		LED2_ON;
		LED3_ON;
	}
	else{
		//sprintf(data,"1111Val:%0.2f V",BAT_Val);
		//NRF_Send_TX(data,32);
		LED2_OFF;
		LED3_OFF;
	}
}*/

int main(void)
{

	 BSP_Int();           //?????ADC?????
	while(1)
	{
		//Bat_Vol_NRF_Tx(); 
		Bat_Vol_NRF_Tx();
		delay(500);
		
	}
	}



