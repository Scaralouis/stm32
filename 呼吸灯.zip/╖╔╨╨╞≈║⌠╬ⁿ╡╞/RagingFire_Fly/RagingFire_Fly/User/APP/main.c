#include "stm32f10x.h"

#include "Led.h"

void De(uint16_t  n)
{
	uint16_t  i,j;
	for( i=0;i<=n;i++)
	{
		for( j=0;j<=8888;j++);
		
	}
}
int main(void)
{
	uint16_t T = 1600;   // ??(????)
	uint16_t i=0,m=0,n=0,t=0;

	LED_Init();   // ????
	LED2_OFF;   // ?

    while (1)
    {
		for (i=0;i<T;i++)
		{
			LED2_ON;  // ?
			LED3_ON;
			for (m=0;m<t;m++);{
			LED2_OFF;   // ?
			LED3_OFF;}
			for (n=0;n<T-t;n++);
			t++;

			if (t >= T)
			{
				for (i=0;i<T;i++)
				{
					LED2_ON;
          LED3_ON;					// ?
					for (m=0;m<t;m++);{
					LED2_OFF;   // ?
					LED3_OFF;}
					for (n=0;n<T-t;n++);
					t--;
				}
			}
		}
    }
}

