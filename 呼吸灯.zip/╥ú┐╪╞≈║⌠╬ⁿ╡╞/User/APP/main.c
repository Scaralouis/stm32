
#include "stm32f10x.h"


#include "Tasks.h"
#include "Maths.h"
#include "Filter.h"
#include "struct_all.h"
static void Delay(uint16_t  num)
{
   uint16_t a=0,b=0;
   for (a=0;a<=num;a++){
   for(b=0;b<=1000;b++);}
}
int main(void)
{
	u16 i;
	LED_Init();

	while(1)
	{
	    for( i = 0; i < 100; i++)
        {
            LEDGreen_ON;
					LEDRed_ON;
            Delay(i);
            LEDGreen_OFF;
					LEDRed_OFF;
            Delay(100 - i);
        }
        for( i = 100; i >0; i--)
        {
            LEDRed_ON;
					  LEDGreen_ON;
            Delay(i);
            LEDRed_OFF;
					  LEDGreen_OFF;
            Delay(100 - i);
        }
	}

}


